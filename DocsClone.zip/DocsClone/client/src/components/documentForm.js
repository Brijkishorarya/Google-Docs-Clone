import { useState } from "react"
import { useDocumentsContext } from "../hooks/useDocumentsContext"
import { useAuthContext } from "../hooks/useAuthContext" 

const WorkoutForm = ({onCreated}) => {
  const { dispatch } = useDocumentsContext()
  const {user} = useAuthContext()

  const [title, setTitle] = useState('')
  const [error, setError] = useState(null)
  const [emptyFields, setEmptyFields] = useState([])


  const handleSubmit = async (e) => {
    e.preventDefault()

    if(!user){
      setError('You must be logged in')
      return
    }

    const document = {title}

    const response = await fetch('http://localhost:5000/api/documents', {
      method: 'POST',
      body: JSON.stringify(document),
      headers: {
        'Content-Type': 'application/json',
        'Authorization' : `Bearer ${user.token}`
      }
    })
    const json = await response.json()

    if (!response.ok) {
      setError(json.error)
      setEmptyFields(json.emptyFields)
    }
    if (response.ok) {
      setTitle('')
      setError(null)
      setEmptyFields([])
      console.log('new document added', json)
      dispatch({type: 'CREATE_DOCUMENT', payload: json})

      onCreated(json._id)
    }
  }

  return (
    <form className="create" onSubmit={handleSubmit}>
      <h3>Create a New Document</h3>

      <label>Title:</label>
      <input 
        type="text"
        onChange={(e) => setTitle(e.target.value)}
        value={title}
        className={emptyFields.includes('title') ? 'error' : ''}
      />

      <button>Create Document</button>
      {error && <div className="error">{error}</div>}
    </form>
  )
}

export default WorkoutForm