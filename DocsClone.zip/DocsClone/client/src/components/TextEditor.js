import { useCallback, useEffect, useState } from "react";
import Quill from "quill";
import "quill/dist/quill.snow.css";
import { io } from "socket.io-client";
import { useParams } from "react-router-dom";
import { useAuthContext } from "../hooks/useAuthContext";

const SAVE_INTERVAL_MS = 2000;
const TOOLBAR_OPTIONS = [
  [{ header: [1, 2, 3, 4, 5, 6, false] }],
  [{ font: [] }],
  [{ list: "ordered" }, { list: "bullet" }],
  ["bold", "italic", "underline"],
  [{ color: [] }, { background: [] }],
  [{ script: "sub" }, { script: "super" }],
  [{ align: [] }],
  ["image", "blockquote", "code-block"],
  ["clean"],
];

export default function TextEditor() {
  const { id: documentId } = useParams();
  const [socket, setSocket] = useState(null); 
  const [quill, setQuill] = useState(null);
  const {user} = useAuthContext()
  const [saveStatus, setSaveStatus] = useState('idle'); 
  const [tokenReady, setTokenReady] = useState(false);

  // Fetch document on component mount or ID change
  useEffect(() => {
    console.log('Fetch useEffect:', user, user?.token);
    const fetchDocument = async () => {
      if (!documentId) return; 

      const response = await fetch(`http://localhost:5000/api/documents/${documentId}`,{
        headers:{
          'Authorization' : `Bearer ${user.token}`
        }
      });
      if (!response.ok) {
        
        console.error("Error fetching document:", response.statusText);
        return; 
      }

      const json = await response.json();
      quill.setContents(json.data); 
      quill.enable();
    };

    if (socket && quill && user && user.token ) {  
      console.log("Ready to fetch", user.token)
      fetchDocument();
    }else {
      console.log("Waiting for dependencies (socket, quill, user, user.token)");
    }
  }, [documentId, socket, quill,user, user.token]);

  // Socket.IO setup
  useEffect(() => {
    const s = io("http://localhost:5000");
    setSocket(s);

    // Receive initial document data (if available on connect)
    s.once("load-document", (documentData) => {
      if (quill) { 
        console.log('Received Initial Document Data:', documentData)
        quill.setContents(documentData); 
        quill.enable(); 
      }
    });

    return () => {
      s.disconnect();
    };
  }, [quill]); 

  // Save Changes
  useEffect(() => {
    if (socket == null || quill == null) return;

    const attemptSave = () => {
        setSaveStatus('loading'); // Indicate saving is in progress
        socket.emit('save-document',
        { data: quill.getContents(), 
          token: user?.token ?? '', 
          documentId: documentId}
      );
        console.log(quill.getContents(), user?.token ?? '')
    };

    // Logic to update tokenReady
    if (user && user.token) { 
        setTokenReady(true); 
    }

    // Only trigger saving if token is ready
    if (tokenReady) {
        const interval = setInterval(attemptSave, SAVE_INTERVAL_MS); 

        // Cleanup function for interval
        return () => clearInterval(interval); 
    }

    // Cleanup for the whole useEffect if dependencies change
    return () => { 
        setTokenReady(false); // Reset tokenReady state
    }; 

}, [socket, quill, documentId, user.token, user, tokenReady]); 

  
  // Receive Real-time Updates
  useEffect(() => {
    if (socket == null || quill == null) return;
  
    const handler = (delta) => {
      console.log('Received Changes:', delta)
      quill.updateContents(delta); 
    };
    socket.on('receive-changes', handler); 
  
    return () => socket.off('receive-changes', handler);
  }, [socket, quill]); 
  
  // Send Local Changes
  useEffect(() => {
    if (socket == null || quill == null) return;
  
    const handler = (delta, oldDelta, source) => {
      if (source !== 'user') return; 
      socket.emit('send-changes', delta); 
    };
    quill.on('text-change', handler); 
  
    return () => quill.off('text-change', handler); 
  }, [socket, quill]); 


  // Quill initialization
  const wrapperRef = useCallback((wrapper) => {
    if (wrapper == null) return

    wrapper.innerHTML = ""
    const editor = document.createElement("div")
    wrapper.append(editor)
    const q = new Quill(editor, {
      theme: "snow",
      modules: { toolbar: TOOLBAR_OPTIONS },
    })
    q.disable()
    q.setText("Loading...")
    setQuill(q) 
  }, []);

  return (
    <div className="container" ref={wrapperRef}> 
      {user && user.token ? (
        <> 
          {saveStatus === 'loading' && <div>Saving...</div>}
        </> 
      ) : (
         <div>Loading ...</div> 
      )}
    </div>
  );
}
