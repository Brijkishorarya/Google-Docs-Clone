import { useDocumentsContext } from '../hooks/useDocumentsContext'
import { useAuthContext } from '../hooks/useAuthContext'

// date fns
import formatDistanceToNow from 'date-fns/formatDistanceToNow'
import { Link } from 'react-router-dom'

const DocumentsDetails = ({ document }) => {
  const { dispatch } = useDocumentsContext()
  const {user} = useAuthContext()

  const handleClick = async () => {
    if(!user){
      return
    }
    const response = await fetch('http://localhost:5000/api/documents' + document._id, {
      method: 'DELETE',
      headers:{
        'Authorization' : `Bearer ${user.token}`
      }
    })
    const json = await response.json()

    if (response.ok) {
      dispatch({type: 'DELETE_DOCUMENT', payload: json})
    }
  }

  return (
    <div className="document-details">
      <h4 key={document._id}>
        <Link to={`/documents/${document._id}`}>
          {document.title}
        </Link>
      </h4>
      <p>{formatDistanceToNow(new Date(document.createdAt), { addSuffix: true })}</p>
      <span className="material-symbols-outlined" onClick={handleClick}>delete</span>
    </div>
  )
}

export default DocumentsDetails