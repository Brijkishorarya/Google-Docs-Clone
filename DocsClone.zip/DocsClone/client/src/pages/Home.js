import { useEffect, useState }from 'react'
import { useNavigate } from 'react-router-dom'
import { useDocumentsContext } from "../hooks/useDocumentsContext"
import {useAuthContext } from '../hooks/useAuthContext'

// components
import DocumentsDetails from '../components/DocumentDetails'
import DocumentForm from '../components/documentForm'

const Home = () => {
  const {documents, dispatch} = useDocumentsContext()
  const {user} = useAuthContext()
  const [redirectId, setRedirectId] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    const fetchDocuments = async () => {
      const response = await fetch('http://localhost:5000/api/documents', {
        headers:{
          'Authorization' : `Bearer ${user.token}`
        }
      })
      const json = await response.json()

      if (response.ok) {
        dispatch({type: 'SET_DOCUMENTS', payload: json})
      }
    }

    if(user){
      fetchDocuments()  
    }
  }, [dispatch, user])

  const handleDocumentCreated = (documentId) => {
    setRedirectId(documentId);
  }

  useEffect(() => {
    if (redirectId) {
      navigate(`/documents/${redirectId}`);
      setRedirectId(null); // Reset after redirect
    }
  }, [redirectId, navigate])

  return (
    <div className="home">
      <div className="documents">
        {documents && documents.map((document) => (
          <DocumentsDetails key={document._id} document={document} />
        ))}
      </div>
      <DocumentForm onCreated={handleDocumentCreated} /> 
    </div>
  )
}

export default Home