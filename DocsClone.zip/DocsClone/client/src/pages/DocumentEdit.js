import React from 'react';
import { useParams } from 'react-router-dom';
import TextEditor from '../components/TextEditor';

const DocumentEditPage = () => {
  const { id: documentId } = useParams(); // Assuming you fetch the document ID

  return (
    // ... other page content
    <TextEditor documentId={documentId} />
  );
};

export default DocumentEditPage;
