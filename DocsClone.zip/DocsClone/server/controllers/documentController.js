const Document = require('../models/DocumentModel'); 
const mongoose = require('mongoose');

// Socket.IO Integration
const io = require('socket.io')(); 

// Error Handling Function
const handleError = (res, error) => {
  console.error(error);
  res.status(500).json({ error: 'Internal Server Error' });
};

// Get all documents
const getDocuments = async (req, res) => {
  try {
    const user_id = req.user._id;
    const documents = await Document.find({ user_id }).sort({ createdAt: -1 });
    res.status(200).json(documents);
  } catch (error) {
    handleError(res, error);
  }
};

// Get a single document with Socket.IO integration
const getDocument = async (req, res) => {
  const { id } = req.params;

  try {
    const document = await Document.findById(id);
    if (!document) {
      return res.status(404).json({ error: 'No such document' });
    }

    // Modified Authorization Check
    if (!document.user_id.equals(req.user._id)) {
      return res.status(401).json({ error: 'Not authorized' });
    }

    // Socket.IO - Join room and send initial data
    io.on('connection', (socket) => {
      socket.on('join-document', ({ documentId }) => {
        console.log('User joined document:', documentId)
        if (documentId === id) {
          socket.join(id);
          socket.emit('load-document', document.data);

          // Handle real-time changes
          socket.on('send-changes', (delta) => {
            console.log('Received Delta:', delta)
            socket.broadcast.to(id).emit('receive-changes', delta);
          });
        }
      });
    });

    res.status(200).json(document);

    console.log('Retrieved Document:', document);          
console.log('Document user_id:', document.user_id); 
console.log('req.user._id:', req.user._id); 
  } catch (error) {
    handleError(res, error);
  }

};


// Create new document
const createDocument = async (req, res) => {
  const { title } = req.body;

  try {
    const user_id = req.user._id;
    const document = await Document.create({ _id: new mongoose.Types.ObjectId(), title, data: {}, user_id });

    // Socket.IO - Emit event for newly created document
    io.emit('new-document', document);

    res.status(200).json(document);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete a document
const deleteDocument = async (req, res) => {
  const { id } = req.params;

  try {
    const document = await Document.findByIdAndDelete(id);

    if (!document) {
      return res.status(404).json({ error: 'No such document' });
    }

    // Socket.IO - Broadcast document deletion
    io.to(id).emit('delete-document', id);

    res.status(200).json(document);
  } catch (error) {
    handleError(res, error);
  }
};

// Update a document
const updateDocument = async (req, res) => {
  const { id } = req.params;

  try {
    const updatedDocument = await Document.findByIdAndUpdate(
      id,
      { ...req.body },
      { new: true }
    );

    if (!updatedDocument) {
      return res.status(404).json({ error: 'No such document' });
    }

    // Socket.IO - Broadcast updated document
    io.to(id).emit('update-document', updatedDocument);

    res.status(200).json(updatedDocument);
  } catch (error) {
    handleError(res, error);
  }
};


module.exports = {
    getDocuments,
    getDocument,
    createDocument,
    deleteDocument,
    updateDocument
  }
