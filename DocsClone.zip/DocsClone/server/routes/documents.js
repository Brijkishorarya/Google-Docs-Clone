const express = require('express')
const {
  createDocument,
  getDocuments,
  getDocument,
  deleteDocument,
  updateDocument
} = require('../controllers/documentController')
const requireAuth = require('../middleware/requireAuth')

const router = express.Router()

// require auth for all
router.use(requireAuth)

// GET all Documents
router.get('/', getDocuments)

//GET a single Document
router.get('/:id',requireAuth, getDocument)

// POST a new Document
router.post('/', createDocument)

// DELETE a Document
router.delete('/:id', deleteDocument)

// UPDATE a Document
router.patch('/:id', updateDocument)


module.exports = router