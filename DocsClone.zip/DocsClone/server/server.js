require('dotenv').config()

const jwt = require('jsonwebtoken');
const express = require('express')
const mongoose = require('mongoose')
const documentRoutes = require('./routes/documents')
const Document = require('./models/DocumentModel')
const userRoutes = require('./routes/user')
const cors = require('cors');


// express app
const app = express()
app.use(cors({ origin: 'http://localhost:3000' })); 

const httpServer = require('http').createServer(app);
const io = require('socket.io')(httpServer); 
const documentController = require('./controllers/documentController')

// middleware
app.use(express.json())
app.use(express.urlencoded({ extended: true }));
 
app.use((req, res, next) => {
    console.log(req.path, req.method)
    next()
  })

  // routes
app.use('/api/documents', documentRoutes)
app.use('/api/user', userRoutes)


// Socket.IO Logic
io.on('connection', (socket) => {
  socket.on('join-document', ({ documentId }) => {
    console.log('User joined document:', documentId)
    socket.join(documentId);

    // Load initial document data 
    const document = loadDocument(documentId); 
    socket.emit('load-document', document.data); 

    socket.on('send-changes', (delta) => {
      console.log('Received Delta:', delta)
      socket.broadcast.to(documentId).emit('receive-changes', delta);
      // Optionally save changes to your database here:
      updateDocumentInDatabase(documentId, delta); // Replace with update logic
    });
  });

 
  // socket.on('save-document', async data => {
  //   const {documentId} = data
  //   await Document.findByIdAndUpdate(documentId, { data })
  //     .catch(error => console.error('Error Saving Document:', error)); 
  // })
  socket.on('save-document', async (data) => {
    const { token,documentId } = data;
    console.log('Received token in save-document:', token);
    try {
      // Authorization Check
      if (!token) {
        // Handle the case where no token is provided
        // Example: Log a message for now, you might want a more robust approach 
        console.error('Document save attempted without authorization token');
        return; // Potentially restrict saving or implement alternative handling.
      }
  
      // Verify token and extract user ID
      const decoded = jwt.verify(token, process.env.SECRET);
      const userId = decoded._id;
  
      // Ensure the user has permission to edit this document (add this if needed)
      const document = await Document.findById(documentId);
      if (!document.user_id.equals(userId)) {
          console.error('Unauthorized document save attempt');
          return; 
      }
  
      // Original saving logic
      await Document.findByIdAndUpdate(documentId, { data }); 
  
    } catch (error) {
      console.error('Error Saving Document:', error);
    }
  });
  


  // 'new-document' event
  socket.on('new-document', (newDocument) => {
    socket.broadcast.emit('new-document', newDocument); 
  });

  // 'delete-document' event
  socket.on('delete-document', (documentId) => {
    socket.broadcast.to(documentId).emit('delete-document', documentId); 
  });
});


// connect to db
mongoose.connect(process.env.MONGO_URI)
  .then(() => {

    httpServer.listen(process.env.PORT, () => {
      console.log('connected to db & Socket.IO listening on port', process.env.PORT) 
       console.log('Server Ready!')
    });
  
  })
  .catch((error) => {
    console.log(error)
  })


  

// Helper Functions 
async function loadDocument(documentId) {
  try {
    const document = await Document.findById(documentId);
    if (!document) {
      throw new Error('Document not found');
    }
    return document; 
  } catch (error) {
    console.error('Error loading document:', error);
    throw error; 
  }
}

async function updateDocumentInDatabase(documentId, delta) {
  try {

    let currentData = await Document.findById(documentId).select('data'); 

    const newContent = new Quill.delta(currentData.data).compose(delta); 
    const updatedDocument = await Document.findByIdAndUpdate(
      documentId,
      { data: newContent.ops },
      { new: true } 
    );

    if (!updatedDocument) {
      throw new Error('Document not found for update');
    }

  } catch (error) {
    console.error('Error updating document:', error);
    throw error; 
  }
}